<?php 
    require_once('admin/connect.php');
    $select = mysqli_query($con,"SELECT * FROM menu ORDER BY position");
    $sel_about = mysqli_query($con,"SELECT * FROM about");
    $fetch_about = mysqli_fetch_assoc($sel_about);
?>

<html>
<head>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel = "stylesheet" href = "css/bootstrap.min.css" />
    <link rel="stylesheet" href="css/all.css">
    <link rel="stylesheet" href="css/style.css">
    <meta charset="utf-8">
    <title>Portfolio</title>
	
	
</head>
<body onload = "writing()">
    <div id="cursor">
        <div class="aura"></div>
    </div>
    <div class="load_div">
        <div class="load_btn">
            <button id="load_btn" class="btn_keira">KEIRA</button>
        </div>
    </div>
    
    <div class="top_btn" id="top_btn">
        <a href="#" class="flex"><i class="fas fa-chevron-up"></i></a>
    </div>
    <header id="home">
        <div class="center flex center_content">
            <div class="logo">
                <img src="images/logo-KEIRA.png">
            </div>
            <nav class="menu">
                <ul class="flex mb-0">
                    <?php 
                        if(mysqli_num_rows($select) > 0){
                            while($fetch = mysqli_fetch_assoc($select)){ ?>
								<li class="menu_li"><a href="#" class="menu_link" data-name = "<?= lcfirst($fetch['name'])?>"><?= $fetch['name']; ?></a></li>
                    <?php
                            }
                        }
                    ?>
                </ul>
            </nav>
            <!---
                <div class = "lang">
                    <a href = "lang.php?lang='en'">English</a>
                    <a href = "lang.php?lang='am'">Armenia</a>
                </div>
            --->
        </div>
    </header>
    
    <section class="first_content">
        <section class="social_left">
            <div class="social_logo">
                <ul>
                    <li class="social_li"><a href="#" class="social_link"><i class="fab fa-facebook-f"></i></a></li>
                    <li class="social_li"><a href="#" class="social_link"><i class="fab fa-linkedin-in"></i></a></li>
                    <li class="social_li"><a href="#" class="social_link"><i class="fab fa-instagram"></i></a></li>
                </ul>
            </div>
            <div class="social_title">
                <p>Follow Me</p>
            </div>
        </section>
        <div class = "first_bg"></div>
         <div class="bg_content">   
            <div class="first_title">
                <h1>I Am Gor Yeghiazaryan</h1>
            </div>
            <div class="sec_title mb-2" id="sec_title">
                <?php 
                    $data = array();
                    $select = mysqli_query($con,"SELECT * FROM slider"); 
                    while($fetch = mysqli_fetch_assoc($select)){ 
                        array_push($data,$fetch['title']);
                    }
                    $data = json_encode($data);
                ?>	
                <p class="par_txt m-0" id="par_txt">
                    <script>
                        var words = <?= $data; ?>;
                    </script>
                </p>
            </div>
            <div class="third_title">
                <ul class="flex bg_ul">
                    <li class="bg_li">
                        <div class="li_title">
                            <p>Morocco</p>
                        </div>
                        <div class="li_content">
                            <p>Rabat - Casablanca</p>
                        </div>
                    </li>
                    <li class="bg_li">
                        <div class="li_title">
                            <p>USA</p>
                        </div>
                        <div class="li_content">
                            <p>Californie - Detroit</p>
                        </div>
                    </li>
                    <li class="bg_li">
                        <div class="li_title">
                            <p>Canada</p>
                        </div>
                        <div class="li_content">
                            <p>Delta - Greenwood</p>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </section>
    <section class = "center flex about_sec" id="about">
        <div class="title about_title">
            <h1>About Us</h1>
        </div>
        <div class="about_content flex">
            <div class="about_left">
                <div class="about_img">
                    <img src="admin/avatar/<?=$fetch_about['img'];?>" alt="About" class="abt_img">
                </div>
            </div>
            <div class="about_right">
                <div class="about_right_title">
                    <h3><?= /*$fetch_about['arm_title'];*/$fetch_about['eng_title']?></h3>
                </div>
                <div class="about_right_content">
                    <p><?= /*$fetch_about['arm_desc'];*/$fetch_about['eng_desc'] ;?></p>
                </div>
                <div class="slide_bar">
                <?php 
                        $select_skill = mysqli_query($con,"SELECT * FROM skill ORDER BY position");
                        if(mysqli_num_rows($select_skill)){
                            while($fetch_skill = mysqli_fetch_assoc($select_skill)){?>
                                <div class = "progress_bar p-2">
                                    <div class = "d-flex justify-content-between">
                                        <label><?= $fetch_skill['skill_name'] ?></label>
                                        <label><?= $fetch_skill['number'] ?>%</label>
                                    </div>
                                    <div class="progress" style = "background-color:#a5a5a5">
                                        <div class="progress-bar" role="progressbar"  style = "width:<?= $fetch_skill['number'];?>%;background-color:ff3d4f">

                                        </div>
                                    </div>
                                </div>
                    <?php
                            }
                        }
                    ?>
                </div>
                <div class="about_btn">
                    <a href="#" class="btn_btn"> Hier Me <i class="fas fa-chevron-right"></i></a>
                </div>
            </div>
        </div>
    </section>
    <section class="center flex services_sec" id="services">
        <div class="services_content flex">
            <div class="branding">
                <div class="services_logo">
                    <a href="#">
                        <img src="images/service_icon2.png">
                    </a>
                </div>
                <div class="services_title">
                    <h2>Branding</h2>
                </div>
                <div class="services_content">
                    <p>To an English person, it will seem like simplified English,told me what</p>
                </div>
            </div>
            <div class="movies">
                <div class="services_logo">
                    <a href="#">
                        <img src="images/service_icon3.png">
                    </a>
                </div>
                <div class="services_title">
                    <h2>Movies</h2>
                </div>
                <div class="services_content">
                    <p>To an English person, it will seem like simplified English,told me what</p>
                </div>
            </div>
            <div class="marketing">
                <div class="services_logo">
                    <a href="#">
                        <img src="images/service_icon4.png">
                    </a>
                </div>
                <div class="services_title">
                    <h2>Marketing</h2>
                </div>
                <div class="services_content">
                    <p>To an English person, it will seem like simplified English,told me what</p>
                </div>
            </div>
        </div>
    </section>

    <section class="num center">
        <div class="num_content flex">
            <div class="firts">
                <div class="sp_title flex">
                    <p>10</p><span>+</span>
                </div>
                <div class="p_title">
                    <p>Happy Client</p>
                </div>
            </div>
            <div class="sec">
                <div class="sp_title flex">
                    <p>950</p><span>+</span>
                </div>
                <div class="p_title">
                    <p>Successful Project</p>
                </div>
            </div>
            <div class="third">
                <div class="sp_title flex">
                    <p>40</p><span>+</span>
                </div>
                <div class="p_title">
                    <p>Team Members</p>
                </div>
            </div>
        </div>
    </section>
    <section class="projects center" id="project">
        <div class="proj_header flex">    
            <div class="title"><h1>Projects</h1></div>
            <div class="btn" style="width: 150px;">
                <a href="#" class="btn_btn"> All Project<i class="fas fa-chevron-right"></i></a>
            </div>
        </div>
        <div class="proj_first flex col-lg-12 flex-row">
            <?php
                $select_all = mysqli_query($con,"SELECT * FROM project ORDER BY position LIMIT 2");
                    while($fetch = mysqli_fetch_assoc($select_all)){?>
                    <div class = "mb-0 proj_cont" style = "width:520px;">
                        <div class="proj_cont_name">
                            <h2><?= $fetch['name'];?></h2>
                            <p><?= $fetch['url'];?></p>
                        </div> 
                            <div class="overlay">
                                <a href="<?= $fetch['url'];?>" class="proj_cont_link"><i class="far fa-eye"></i></a>
                            </div>
                            <div class="img">
                                <a href="<?= $fetch['url'];?>">
                                    <img src="admin/proj_img/<?= $fetch['img'];?>" alt="13">
                                </a>
                            </div>
                    </div>
            <?php
                }
            ?>
        </div>
        <div class="proj_sec flex">
        <?php
                $select_all = mysqli_query($con,"SELECT * FROM project ORDER BY position LIMIT 3");
                    while($fetch = mysqli_fetch_assoc($select_all)){?>
                    <div class = "mb-0 proj_cont" style = "width:520px;">
                        <div class="proj_cont_name">
                            <h2><?= $fetch['name'];?></h2>
                            <p><?= $fetch['url'];?></p>
                        </div> 
                            <div class="overlay">
                                <a href="<?= $fetch['url'];?>" class="proj_cont_link"><i class="far fa-eye"></i></a>
                            </div>
                            <div class="img">
                                <a href="<?= $fetch['url'];?>">
                                    <img src="admin/proj_img/<?= $fetch['img'];?>" alt="13">
                                </a>
                            </div>
                    </div>
            <?php
                }
            ?>
        </div>
    </section>

    <section class="resume center flex" id="portfolio">
        <div class="res_header">    
            <div class="title"><h1>Resume</h1></div>
        </div>
            <div class="res_content flex">
                <div class="first_res">
                    <div class="first_res_title">
                        <h3>Experince.</h3>
                    </div>
                    <div class="first_res_content">
                        <p>
                            To an English person, it will seem like simplified English,
                             as a skeptical Cambridge friend of mine.
                        </p>
                    </div>
                    <div class="line"></div>
                    <div class="txt_1">
                        <h3>Photo Agency Shutter</h3>
                        <p>Photographer-intern 2016–2017</p>
                    </div>
                    <div class="txt_2">
                        <h3>Studio e.Oliver</h3>
                        <p>Photographer-retoucher 2017–Present</p>
                    </div>
                </div>
                <div class="sec_res">
                    <div class="sec_res_title">
                        <h3>Education.</h3>
                    </div>
                    <div class="sec_res_content">
                        <p>
                            To an English person, it will seem like simplified English,
                            as a skeptical Cambridge friend of mine
                        </p>
                    </div>
                    <div class="line_sec"></div>
                    <div class="txt_1">
                        <h3>Photography School</h3>
                        <p>New York Film Academy 2010–2012</p>
                    </div>
                    <div class="txt_2">
                        <h3>Photography Universities</h3>
                        <p>Bloomfield Hills, MI 2013–2015</p>
                    </div>
                </div>
                <div class="third_res">
                    <div class="third_res_title">
                        <h3>Equipment.</h3>
                    </div>
                    <div class="third_res_content">
                        <p>
                            To an English person, it will seem like simplified English,
                             as a skeptical Cambridge friend of mine.
                        </p>
                    </div>
                    <div class="line_third"></div>
                    <div class="txt_1">
                        <h3>Digital cameras</h3>
                        <p>Canon EOS 5D Mark IV Sony Alpha</p>
                    </div>
                    <div class="txt_2">
                        <h3>Video camera</h3>
                        <p>Sony AX53 4K Handycam</p>
                    </div>
                </div>
            </div>
    </section>
    <section class="team center" id="team">
        <div class="team_header">    
            <div class="title team_title"><h1>Our Team Showcase</h1></div>
        </div>
        <div class="team_content flex">
            <div class="first_team">
                <a href="#" class="team_link">
                        <div class="team_img">
                            <img src="images/1.jpg">
                            <div class="absolute">
                                <ul class="flex social_ul">
                                    <li class="social_menu flex"><a href="#" class="social_href"><i class="fab fa-facebook-f"></i></a></li>
                                    <li class="social_menu"><a href="#" class="social_href"><i class="fab fa-twitter"></i></a></li>
                                    <li class="social_menu"><a href="#" class="social_href"><i class="fab fa-linkedin-in"></i></a></li>
                                    <li class="social_menu"><a href="#" class="social_href"><i class="fab fa-instagram"></i></i></a></li>
                                    <li class="social_menu"><a href="#" class="social_href"><i class="fab fa-behance"></i></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="team_desc">
                            <h2>Razan Mark</h2>
                            <p>Founder</p>
                        </div>
                </a>
            </div>
            <div class="sec_team">
                <a href="#" class="team_link">
                    <div class="team_img">
                        <img src="images/2.jpg">
                        <div class="absolute">
                            <ul class="flex social_ul">
                                <li class="social_menu flex"><a href="#" class="social_href"><i class="fab fa-facebook-f"></i></a></li>
                                <li class="social_menu"><a href="#" class="social_href"><i class="fab fa-twitter"></i></a></li>
                                <li class="social_menu"><a href="#" class="social_href"><i class="fab fa-linkedin-in"></i></a></li>
                                <li class="social_menu"><a href="#" class="social_href"><i class="fab fa-instagram"></i></i></a></li>
                                <li class="social_menu"><a href="#" class="social_href"><i class="fab fa-behance"></i></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="team_desc">
                        <h2>Alexander Doe</h2>
                        <p>Designer</p>
                    </div>
                </a>
            </div>
            <div class="third_team">
                <a href="#" class="team_link">
                    <div class="team_img">
                        <img src="images/3.jpg">
                        <div class="absolute">
                            <ul class="flex social_ul">
                                <li class="social_menu flex"><a href="#" class="social_href"><i class="fab fa-facebook-f"></i></a></li>
                                <li class="social_menu"><a href="#" class="social_href"><i class="fab fa-twitter"></i></a></li>
                                <li class="social_menu"><a href="#" class="social_href"><i class="fab fa-linkedin-in"></i></a></li>
                                <li class="social_menu"><a href="#" class="social_href"><i class="fab fa-instagram"></i></i></a></li>
                                <li class="social_menu"><a href="#" class="social_href"><i class="fab fa-behance"></i></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="team_desc">
                        <h2>Elina Fitnesh</h2>
                        <p>App Developer</p>
                    </div>
                </a>
            </div>
        </div>
    </section>
    <section class="center blog" id="news">
        <div class="blog_header">    
            <div class="title blog_title"><h1>Recent Blog</h1></div>
        </div>
        <div class="blog_content flex">
            <div class="firts_blog">
                <div class="blog_img">
                    <div class="transform"></div>
                    <a href="#">
                        <img src="images/4.jpg">
                    </a>
                </div>
                <div class="blog_desc">
                    <a href="#" class="blog_link">Ways To Motivate Yourself</a>
                    <p class="blog_txt">
                        Ways To Motivate Yourself. Lorem ipsum dolor sit amet,
                        consectetur adipisicing elit, sed do eiusmod …
                    </p>
                </div>
            </div>
            <div class="sec_blog">
                <div class="blog_img">
                    <div class="transform"></div>
                    <a href="#">
                        <img src="images/5.jpg">
                    </a>
                </div>
                <div class="blog_desc">
                    <a href="#" class="blog_link">Create A WordPress Theme</a>
                    <p class="blog_txt">
                        Create a WordPress Theme. Lorem ipsum dolor sit amet, 
                        consectetur adipisicing elit, sed do eiusmod …
                    </p>
                </div>
            </div>
            <div class="third_blog">
                <div class="blog_img">
                    <div class="transform"></div>
                    <a href="#">
                        <img src="images/6.jpg">
                    </a>
                </div>
                <div class="blog_desc">
                    <a href="#" class="blog_link">Top Graphic Design Topics</a>
                    <p class="blog_txt">
                        Top Graphic Design Topics. Lorem ipsum dolor sit amet,
                        consectetur adipisicing elit, sed do eiusmod …
                    </p>
                </div>
            </div>
        </div>
    </section>
    <section class="contact center" id = "contact">
        <div class="contact_header">    
            <div class="title contact_title"><h1>Get In Touch</h1></div>
        </div>
        <div class="cotact_content flex">
            <div class="left_content">
                <div class="info_contact">
                    <h4>Email</h4>
                    <p>Support@Example.Com</p>
                    <p>Support@Example.Com</p>
                </div>
                <div class="info_contact">
                    <h4>CALL US</h4>
                    <p>700 001 70 16</p>
                    <p>700 1414 34 11</p>
                </div>
                <div class="info_contact">
                    <h4>ADDRESS</h4>
                    <p>405, Royal Square, Nr.</p>
                    <p>ARLINGTON VA 41174, USA</p>
                </div>
            </div>
            <div class="contact_form">
                <div class="first_form flex">
                    <div>
                        <input type="text" id="marg" class="form_inp" placeholder="Username *">
                        <p></p>
                    </div>
                    <div>
                        <input type="text" id="marg" class="form_inp" placeholder="Email *">
                        <p></p>
                    </div>
                    <div>
                        <input type="text" id="marg" class="form_inp" placeholder="Phone *">
                        <p></p>
                    </div>
                </div>
                <div class="sec_form">
                    <textarea placeholder="Message"></textarea>
                </div>
                <div class="third_form">
                    <button type="button" class="contact_btn"><i class="fas fa-paper-plane"></i>Send Message</button>
                </div>
                <div class="error_message">

                </div>
            </div>
        </div>
    </section>
    <section class="social_sec">
        <div class="center contact_social_icon">
            <ul class="flex social_ul">
                <li class="social_menu flex"><a href="#" class="social_href"><i class="fab fa-facebook-f"></i></a></li>
                <li class="social_menu"><a href="#" class="social_href"><i class="fab fa-twitter"></i></a></li>
                <li class="social_menu"><a href="#" class="social_href"><i class="fab fa-linkedin-in"></i></a></li>
                <li class="social_menu"><a href="#" class="social_href"><i class="fab fa-instagram"></i></i></a></li>
                <li class="social_menu"><a href="#" class="social_href"><i class="fab fa-behance"></i></i></a></li>
            </ul>
        </div>
    </section>
    <footer>
        <div class="footer_content flex center">
            <div class="left_footer_content flex">
                <span class="span_txt">&copy Copyrights Inaikas 2021. All Rights Reserved.</span>
            </div>
            <div class="right_footer_content flex">
                <div class="right_footer_content_span">
                    <span class="span_txt">Newsletter Signup</span>
                </div>
                <div class="right_footer_content_email">
                    <input type="text" placeholder="E-mail *" class="email_inp">
                    <div class="font"><i class="fas fa-envelope"></i></div>
                </div>
            </div>
        </div>
		
		<script src="js/jquery.js"></script>
        	<script src = "js/bootstrap.min.js"></script>
		<script src="js/main.js"></script>
		
    </footer>

    
</body>
</html>