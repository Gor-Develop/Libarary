<?php 
	require('connect.php');
	require_once('header.php');
	require_once('navbar.php');

?>
				<div class = "col-lg-10 p-5">
					Welcome Admin Page
				</div>


<?php
	require_once ('footer.php');
?>