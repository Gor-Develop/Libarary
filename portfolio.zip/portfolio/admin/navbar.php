
					<div class = "col-lg-2">
						<div class = "position-fixed nav_fixed bg-primary">
							<ul>
								<li>
									<a href = "/myproject/portfolio/admin/admin.php">
										Home
									</a>
								</li>
								<li>
									<a href = "/myproject/portfolio/admin/personal.php">
										Personal Settings
									</a>
								</li>
								<li>
									<a href = "/myproject/portfolio/admin/menu.php">
										Menu
									</a>
								</li>
								<li>
									<a href = "/myproject/portfolio/admin/slider.php">
										Slider
									</a>
								</li>
								<li>
									<a href = "/myproject/portfolio/admin/about.php">
										About
									</a>
								</li>
								<li>
									<a href = "/myproject/portfolio/admin/project.php">
										Project
									</a>
								</li>
							</ul>
						</div>
					</div>