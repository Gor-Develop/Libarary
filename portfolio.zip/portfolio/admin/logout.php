<?php

	session_start();
	if(isset($_SESSION['admin'])){
		
		if(isset($_COOKIE['username']) || isset($_COOKIE['password'])){
			setcookie('username',$_SESSION['admin']['username'],time()-3600*24);
			setcookie('password',$_SESSION['admin']['password'],time()-3600*24);
		}
		unset($_SESSION['admin']);
		header("Location:/myproject/portfolio/admin/");
	}
		else{
			header("Location:404.php");
		}
?>