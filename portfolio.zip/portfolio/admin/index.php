<?php 
	
	session_start();
    require_once('connect.php');
    $log_errors = '';
	if(isset($_COOKIE['username']) && $_COOKIE['password']){
		$username = $_COOKIE['username'];
		$password = $_COOKIE['password'];
		$result = mysqli_query($con, "SELECT * FROM admin 
										WHERE username = '$username' AND
											  password = '$password'
										");
				if(mysqli_num_rows($result) == 1){
					$_SESSION['admin'] = mysqli_fetch_assoc($result);
					header("Location:admin.php");
				}
	}
    if(isset($_POST['submit'])){
		$username = $_POST['username'];
		$password = $_POST['password'];
		if(empty($username) && empty($password)){
			$log_errors = '<div class="alert alert-danger" role="alert">
												Fill All Fields
											</div>';
		}
			else{
				$result = mysqli_query($con, "SELECT * FROM admin 
										WHERE username = '$username' AND
											  password = '$password'
										");
				if(mysqli_num_rows($result) == 0){
					$log_errors = '<div class="alert alert-danger" role="alert">
														Wrong Email or Password
													</div>';
				}else{
					$_SESSION['admin'] = mysqli_fetch_assoc($result);
					if(isset($_POST['checked'])){
						setcookie('username',$username,time()+3600*24);
						setcookie('password',$password,time()+3600*24);
					}
						header("Location:admin.php");
				}
			}	
	}


?>
<html lang="en">
<head>
		<link rel = "stylesheet" href = "css/bootstrap.min.css" />
		<link rel = "stylesheet" href = "css/all.css" />
		<link rel = "stylesheet" href = "css/style.css" />
</head>
<body class = "bg-dark bg-gradient">
    <div class = "container w-25 my-5">
        <div class = "row">
                <form action = '' method = 'post'>
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label fw-bold">Username</label>
                        <input type="text" name = "username" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label fw-bold">Password</label>
                        <input type="password" name = "password" class="form-control" id="exampleInputPassword1">
                    </div>
                    <div class="mb-3 form-check">
                        <input type="checkbox" name = "checked" class="form-check-input" id="exampleCheck1">
                        <label class="form-check-label fw-normal text-white" for="exampleCheck1">Check me out</label>
                    </div>
                    <button type="submit" name = "submit" class="btn btn-outline-success w-100">Submit</button>
                    <div class = "error mt-3"><?=$log_errors?></div>
                </form>
        </div>
    </div>
</body>
</html>