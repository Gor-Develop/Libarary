<?php 
    require_once('connect.php');
    require('header.php');
    require('navbar.php');
    $log_error = "";
    if(isset($_POST['update_settings'])){
        $username = $_POST['username'];
        $password = $_POST['password'];
        if(empty($username) || empty($password)){
			$log_error = '<div class="alert alert-danger" role="alert">
								  Fill All Fields
								</div>';
		}
			else{
				$update = mysqli_query($con, "UPDATE admin SET username = '$username',password = '$password'");
				if($update){
					$_SESSION['admin']['username'] = $username;
					$_SESSION['admin']['password'] = $password;
				}
			}
	}
    $result = mysqli_query($con,"SELECT * FROM admin");
    $fetch = mysqli_fetch_assoc($result);
?>
<div class = "col-lg-10">
					<form action = "" method = "post">
						<div class = "pt-5">
							<h2 class = "mb-3"> Change Personal Settings</h2>
						</div>
						<div class="row g-3 align-items-center">
						  <div class="col-auto">
							<label for="username" class="col-form-label">Username</label>
						  </div>
						  <div class="col-auto">
							<input type="text" id="username" class="form-control" aria-describedby="passwordHelpInline" value = "<?= $fetch['username'];?>" name = "username">
						  </div>
						  <div class="col-auto">
							<label for="password" class="col-form-label">Password</label>
						  </div>
						  <div class="col-auto">
							<input type="password" id="password" class="form-control admin_pass" aria-describedby="passwordHelpInline"value = "<?= $fetch['password'];?>" name = "password">
						  </div>
						  <div class="col-auto">
							<i class="fa-solid fa-eye  pass_show_hide"></i>
						  </div>
						  <div class="col-auto">
							<button type="submit" class="btn btn-success" name = "update_settings">Save</button>
						  </div>
						  <div>
							<?= $log_error;?>
						  </div>
						</div>
					</form>
				</div>
<?php 
    require('footer.php');
?>