<?php 
require_once('connect.php');
require_once('header.php');
require_once('navbar.php');
$error = '';
if(isset($_POST['add_menu'])){
    $menu_name = $_POST['menu'];
        if(empty($menu_name)){
            $error = '<div class="alert alert-danger" role="alert">
                        Fill All Fields
                    </div>';
        }
            else{
                $insert = mysqli_query($con,"INSERT INTO menu (name)VALUES ('$menu_name')");
                if($insert){
                    $select = mysqli_query($con,"SELECT * FROM menu WHERE name = '$menu_name'");
                    $fetch = mysqli_fetch_assoc($select);
                }
            }   
}
?>

        <div class = "col-lg-10">
                <div class = "row pt-5 align-items-center">
                    <div class = "col-auto">
                        <label for="menu_txt" class="col-form-label">Add Menu</label>
                    </div>
                    <div class = "col-auto">
                        <input type="text"  name="menu" id="menu_txt" class="form-control">
                    </div>
                    <div class="col-auto">
                        <button type="submit" class="btn btn-primary add_menu">Add Menu</button>
                    </div>
                </div>
            
                <?php $error; ?>
                <div class = "sortable_table mt-4">
                       <?php 
                            $select = mysqli_query($con,"SELECT * FROM menu ORDER BY position");
                            if(mysqli_num_rows($select) > 0){
                                while($fetch = mysqli_fetch_assoc($select)){
                                    $menu_title = $fetch['name'];
                                    $menu_id = $fetch['id'];
                        ?>
                        <ul class = "" data-position = "<?= $fetch['position'] ?>" data-index = "<?= $fetch['id'] ?>">
                            <li class = "list-unstyled li_item d-flex align-items-center" >
                                <span class = "menu_title me-2"><?= $menu_title; ?></span>
                                <div class = "del_prog m-3 d-flex align-items-center">
                                    <i class="fa-solid fa-times delete"  data-title_id = "<?= $fetch['id'] ?>"></i>
                                </div>
                            </li>
                        </ul>
                        <?php 
                                }
                             }
                       ?>
                       
                </div>               
        </div>

<?php
    require_once('footer.php');
?>
