<?php
/*------------Add Menu Field--------------*/
    if(isset($_POST['key']) &&  $_POST['key'] == 'add'){
        require_once('../connect.php');
        $menu_name = $_POST['name'];
		
			$insert = mysqli_query($con,"INSERT INTO menu (name)VALUES ('$menu_name')");
			if($insert){
                echo 1;
				$select = mysqli_query($con,"SELECT * FROM menu");
                $fetch = mysqli_fetch_assoc($select);
                 
			}
    }
/*------------Delete Menu Field--------------*/
    if(isset($_POST['key']) &&  $_POST['key'] == 'delete_menu'){
        require_once('../connect.php');
        $title_id = $_POST['title_id'];
		
			$delete = mysqli_query($con,"DELETE FROM menu WHERE id = '$title_id'");
			if($delete){
                echo 1;
				$select = mysqli_query($con,"SELECT * FROM menu");
                $fetch = mysqli_fetch_assoc($select); 

			}
    }

/*------------Add Slider-----  PROBLEM ---------*/
    if(isset($_POST['key']) &&  $_POST['key'] == 'add_slider'){
        require_once('../connect.php');
        $slider_name = $_POST['slider_name'];
		//var_dump($slider_name);exit;
        //mysqli_error($con);exit;
        $insert = mysqli_query($con,"INSERT INTO slider(title) VALUES('$slider_name')");
           //mysqli_error($con);exit;
			if($insert){
                echo 2;
				$select = mysqli_query($con,"SELECT * FROM slider");
                $fetch = mysqli_fetch_assoc($select);
			}
                else{
                    echo '0';
                }
                var_dump($insert);exit;
    }
/*------------Delete Slider--------------*/
    if(isset($_POST['key']) &&  $_POST['key'] == 'delete_slider'){
        require_once('../connect.php');
        $slider_id = $_POST['slider_id'];
		
			$delete = mysqli_query($con,"DELETE FROM slider WHERE id = '$slider_id'");
			if($delete){
                echo 1;
				$select = mysqli_query($con,"SELECT * FROM slider");
                $fetch = mysqli_fetch_assoc($select); 

			}
    }
/*------------Delete Progress--------------*/
if(isset($_POST['key']) &&  $_POST['key'] == 'delete_progress'){
    require_once('../connect.php');
    $progress_id = $_POST['progress_id'];
    
        $delete = mysqli_query($con,"DELETE FROM skill WHERE id = '$progress_id'");
        if($delete){
            echo 1;
            $select = mysqli_query($con,"SELECT * FROM skill");
            $fetch = mysqli_fetch_assoc($select); 

        }
}
/*------------Delete Project--------------*/
if(isset($_POST['key']) &&  $_POST['key'] == 'delete_project'){
    require_once('../connect.php');
    $project_id  = $_POST['project_id'];
    
        $delete = mysqli_query($con,"DELETE FROM project WHERE id = '$project_id'");
        if($delete){
            echo 1;
            $select = mysqli_query($con,"SELECT * FROM project");
            $fetch = mysqli_fetch_assoc($select); 

        }
}
/*------------Sortable Menu--------------*/
if(isset($_POST['key']) &&  $_POST['key'] == 'sortable'){
    require_once('../connect.php');
    foreach($_POST['position'] as $position){
        $index = $position[0];
        $new_position = $position[1];
        $update_position = mysqli_query($con,"UPDATE menu SET position = '$new_position' WHERE id = '$index'");
        
    }
}
/*------------Sortable About--------------*/
if(isset($_POST['key']) &&  $_POST['key'] == 'sortable'){
    require_once('../connect.php');
    foreach($_POST['position'] as $position){
        $index = $position[0];
        $new_position = $position[1];
        $update_position = mysqli_query($con,"UPDATE skill SET position = '$new_position' WHERE id = '$index'");
    }
}
/*------------Sortable Project--------------*/
if(isset($_POST['key']) &&  $_POST['key'] == 'sortable'){
    require_once('../connect.php');
    foreach($_POST['position'] as $position){
        $index = $position[0];
        $new_position = $position[1];
        $update_position = mysqli_query($con,"UPDATE project SET position = '$new_position' WHERE id = '$index'");
    }
}
?>