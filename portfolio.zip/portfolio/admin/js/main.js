$('.submit').click(function(){
    $username = $('.username_inp').val();
    $password = $('.pass_inp').val();

    $.ajax({
        url:'ajax/ajax.php',
        type:'post',
        dataType:'JSON',
        data:{'username':$username,'password':$password,key:'yes'},
        success:function(res){
            console.log(res);
            $('.error_div').html(res);
        }
    })
})