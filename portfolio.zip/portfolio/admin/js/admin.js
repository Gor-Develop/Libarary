// --------- Chanege Username Or Password ------- //

$('.pass_show_hide').click(function(){
	 pass_type = $('.admin_pass').attr('type');
	if(pass_type == 'password'){
		$('.admin_pass').attr('type','text');

	}
		else{
			$('.admin_pass').attr('type','password');
		}
        $('.pass_show_hide').toggleClass('fa-eye fa-eye-slash');
})

// --------- Add Menu Fields ------- //
$('.add_menu').click(function(){
	//
    menu_name = $('#menu_txt').val();
	if(menu_name != ''){
		$.ajax({
			url:'ajax/ajax.php',
			type:'post',
			data:{name:menu_name,key:'add'},
			success:function(res){
				if(res == 1){
					$('.table').append('<li class = "list-unstyled li_item">'+
											'<span class = "menu_title me-2">'+menu_name+'</span>'+
											'<i class="fa-solid fa-times show_modal" data-bs-toggle="modal" data-bs-target="#yes_no"></i>'+
										'</li>');
				}
			}
		})
	}
		else{
			$('.table').html('<div class="alert alert-danger" role="alert">'+
								'Fill All Fields'+
							'</div>');
		}
		
	$('#menu_txt').val('');
})
// --------- Delete Menu Fields ------- //
$('.delete').click(function(){
	title_id = ($(this).data('title_id'));

	$.ajax({
		url:'ajax/ajax.php',
		type:'post',
		data:{title_id:title_id,key:'delete_menu'},
		success:function(res){
			if(res == 1){
				$('.li_item').remove();
			}
		}
	})
})
// --------- Add Slider ------- //
$('.add_slider').click(function(){
    slider_name = $('.slider_title').val();
	if(slider_name != ''){
		$.ajax({
			url:'ajax/ajax.php',
			type:'post',
			data:{slider_name:slider_name,key:'add_slider'},
			success:function(res){
				if(res == 1){
					$('.table').append('<li class = "list-unstyled li_item">'+
											'<span class = "menu_title me-2">'+slider_name+'</span>'+
											'<i class="fa-solid fa-times show_modal" data-bs-toggle="modal" data-bs-target="#yes_no"></i>'+
										'</li>');
				}
			}
		})
	}
		else{
			$('.table').html('<div class="alert alert-danger" role="alert">'+
								'Fill All Fields'+
							'</div>');
		}
		
	$('.slider_title').val('');
})
// --------- Delete Slider ------- //
$('.delete').click(function(){
	slider_id = ($(this).data('slider_id'));

	$.ajax({
		url:'ajax/ajax.php',
		type:'post',
		data:{slider_id:slider_id,key:'delete_slider'},
		success:function(res){
			if(res == 1){
				$('.li_item').remove();
			}
		}
	})
})
//--------------- Display Selected Image ----------//

$('#profile_image').change(function(){
    $('.profile_error_message').html('');
    var file = $('#profile_image').get(0).files[0];
    if (file) {
        var array = file.name.split('.');
        var format = array[array.length-1];
        if( format == 'jpg'  ||
            format == 'png'  ||
            format == 'jpeg' ||
            format == 'gif'  ||
            format == 'webp')
        {
            var fileReader = new FileReader();
            fileReader.readAsDataURL(file);
            fileReader.addEventListener("load", function () {
                $('.user_avatar_edit').attr('src', this.result);
            });
			$('.profile_error_message').html('');
        }else {
            $('.profile_error_message').append( '<div class="alert alert-danger" role="alert">\n' +
                                                '  File type is incorrect!\n' +
                                                '</div>');
        }

    }
})
// --------- Delete Progress ------- //
$('.delete').click(function(){
	progress_id = ($(this).data('progress_id'));

	$.ajax({
		url:'ajax/ajax.php',
		type:'post',
		data:{progress_id:progress_id,key:'delete_progress'},
		success:function(res){
			if(res == 1){
				$('.progress_bar').remove();
			}
		}
	})
})
// --------- Delete Project ------- //
$('.delete').click(function(){
	project_id = ($(this).data('project_id'));

	$.ajax({
		url:'ajax/ajax.php',
		type:'post',
		data:{project_id:project_id,key:'delete_project'},
		success:function(res){
			if(res == 1){
				$('.proj_list').remove();
			}
		}
	})
})
// --------- Menu Sortable ------- //
$('.sortable_table').sortable({
	
	update:function(event,ui){
		$(this).children().each(function(index){
			if($(this).attr('data-position') != (index+1)){
				$(this).attr('data-position', (index+1)).addClass('updated');
			}
		})
		new_sortable();
	}
});
function new_sortable(){
	var position = [];

	$('.updated').each(function(){
		position.push([$(this).attr('data-index'), $(this).attr('data-position')]);
		$(this).removeClass('updated');
	})

	$.ajax({
		url:'ajax/ajax.php',
		type:'post',
		data:{position:position,key:'sortable'},
		success:function(res){
			
		}
	});

	console.log(position);
}