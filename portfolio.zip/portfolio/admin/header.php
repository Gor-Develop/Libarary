<?php
	session_start();
	if(!isset($_SESSION['admin'])){
		header('Location:/myproject/portfolio/admin/404.php');
	}
?>




<!DOCTYPE html>
<html lang="en">
<head>
        <link rel = "stylesheet" href = "css/bootstrap.min.css" />
		<link rel = "stylesheet" href = "css/all.css" />
		<link rel = "stylesheet" href = "css/style.css" />
		<meta charset = "utf-8">
</head>
<body>
<header>
			<div class = "bg-dark" style = "min-height:80px;">
				<div class = "container d-flex justify-content-end fixed-top header_fixed">
					<div class = "mx-2">
						<p class = "text-right text-light border-end px-2">
							<?= $_SESSION['admin']['name'].' '.$_SESSION['admin']['surname']?>
						</p>
					</div>
					<div class = "mx-2">
						<a href = "logout.php" style = "color:#fff;">Logout</a>
					</div>
				</div>
			</div>
		</header>
		<div class = "container-fluid">
			<div class = "row">
