<?php 
    session_start();
    $lang_ses = $_SESSION['lang'];
    if($_GET['lang']){
        $link_lang = $_GET['lang'];
        if($link_lang == 'en'){
            
        }
    }

?>