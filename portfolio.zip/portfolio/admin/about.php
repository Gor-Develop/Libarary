<?php

require_once('connect.php');
require_once('header.php');
require_once('navbar.php');
require_once('functions.php');

$error_message ='';
if(isset($_POST['avatar_sub'])){
    $file_name = $_FILES['avatar']['name'];
    $file_tmp = $_FILES['avatar']['tmp_name'];
        if($file_name != ''){
            $upload = upload_file($file_tmp,$file_name,"avatar/");
            $new_file_name = $upload['data'];
            if($upload['status'] == 'success'){
                $update = mysqli_query($con,"UPDATE about SET  img = '$new_file_name'");
                if($update){
                    $select_img = mysqli_query($con,"SELECT * FROM about");
                    $fetch = mysqli_fetch_assoc($select_img);
                }
                
            }
            
            
        }

}

if(isset($_POST['form_sub'])){
    foreach($_POST as $key=>$value){
        $$key = cleanPosts($value);
        
    }
    $update = mysqli_query($con, "UPDATE about SET
                                                arm_title = '$arm_title',
                                                arm_desc = '$arm_desc',
                                                eng_title = '$eng_title',
                                                eng_desc = '$eng_desc'");

            
}
$select = mysqli_query($con,"SELECT * FROM about");
$fetch = mysqli_fetch_assoc($select); 


if(isset($_POST['skill_sub'])){
    foreach($_POST as $key=>$value){
        $$key = cleanPosts($value);;
    }
    $insert = mysqli_query($con,"INSERT INTO skill (skill_name, number) VALUES ('$skill_name','$skill_num')");
    if($insert){
        //echo 2;
    }
}
?>




            <div class = "col-lg-10">
                <div class = "row pt-5 align-items-center">
                        <!----- Change AVATaR ------>
                        <div class = "col-lg-2 row">
                            <form action = "" method = "post" enctype = "multipart/form-data" class = "row w-100">
                                    <div class = "mb-2  border">
                                        <img src = "" class = "w-100 user_avatar_edit fas fa-image">
                                    </div>
                                    <div class="mt-2">
                                        <input type="file"  name = "avatar" class="form-control w-100" id="profile_image" aria-describedby="inputGroupFileAddon04" aria-label="Upload">
                                    </div>
                                    <div class="save_avatar_btn_content mt-2">
                                        <input type = "submit" name = "avatar_sub" class = "btn btn-success w-100" value = "Save">
                                    </div>
                                    <div class = "mt-2">
                                        <?= $error_message; ?>
                                    </div>
                            </form>
                        </div>
                        <!----- TEXT ------>
                        <form action = "about.php" method = "post" class = "row txt_form">
                            <div class = "col-lg-5">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Arm Title</label>
                                    <input type="text" name = "arm_title" class="form-control" id="exampleInputEmail1" value = "<?= $fetch['arm_title'];?>" aria-describedby="emailHelp" placeholder="Enter title">
                                </div>
                                <div class="form-group mt-2">
                                    <label for="exampleInputPassword1">Arm Desc</label>
                                    <textarea name = "arm_desc" class="form-control"   placeholder="Enter Desc"><?= $fetch['arm_desc'];?></textarea>
                                </div>
                            </div>

                            <div class = "col-lg-5">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Eng Title</label>
                                    <input type="text" name = "eng_title" class="form-control" id="exampleInputEmail1" value = "<?= $fetch['eng_title'];?>" aria-describedby="emailHelp" placeholder="Enter title">
                                </div>
                                <div class="form-group mt-2">
                                    <label for="exampleInputPassword1">Eng Desc</label>
                                    <textarea type="text" name = "eng_desc" class="form-control"   placeholder="Enter Desc"><?= $fetch['eng_desc'];?></textarea>
                                </div>
                            </div>
                            <input type="submit" name = "form_sub" class="btn btn-primary mt-2" style = "width:83%;" >
                        </form>
                        <!----- Skill ------>
                        <form  action = "" method = "post" class ="row mt-4">
                            <div class ="col-lg-5">
                                <label class="sr-only" for="inlineFormInputName2">Name</label>
                                <input type="text" name = "skill_name" class="form-control mb-2 mr-sm-2" id="inlineFormInputName2" placeholder="Name">
                            </div>
                            <div class = "col-lg-5">
                                <label class="sr-only" for="inlineFormInputGroupUsername2">Skill Prcent</label>
                                <input type="number" name = "skill_num" class="form-control" min = "1" max = "100" id="inlineFormInputGroupUsername2" placeholder="Prcent">
                            </div>
                            <div class = "col-lg-2">
                                <input type="submit" name = "skill_sub" class="btn btn-primary mb-2" value = "Save">
                            </div>
                        </form>
                    <div class = "sortable_table">
                        <?php 
                            $select_skill = mysqli_query($con,"SELECT * FROM skill ORDER BY position");
                            if(mysqli_num_rows($select_skill)){
                                while($fetch_skill = mysqli_fetch_assoc($select_skill)){?>
                                    <div class = "progress_bar p-2 d-flex" data-position = "<?= $fetch_skill['position'] ?>" data-index = "<?= $fetch_skill['id'] ?>">
                                        <div class = "all_prog w-75">
                                            <div class = "d-flex justify-content-between">
                                                <label><?= $fetch_skill['skill_name'] ?></label>
                                                <label><?= $fetch_skill['number'] ?>%</label>
                                            </div>
                                            <div class="progress">
                                                <div class="progress-bar" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style = "width:<?= $fetch_skill['number'];?>%"></div>
                                            </div>
                                        </div>
                                        <div class = "del_prog m-3 d-flex align-items-center">
                                                <i class="fa-solid fa-times delete" data-progress_id = "<?= $fetch_skill['id'] ?>"></i>
                                        </div>
                                    </div>
                        <?php
                                }
                            }
                        ?>
                    </div>
                </div>             
            </div>


<?php

require_once('footer.php');
?>