<?php

require_once('connect.php');
require_once('header.php');
require_once('navbar.php');
require_once('functions.php');
$error_message = '';
if(isset($_POST['save'])){
    $file_name = $_FILES['images']['name'];
    $file_tmp = $_FILES['images']['tmp_name'];
    $name = $_POST['proj_name'];
    $link = $_POST['proj_url'];
        if($name != '' && $link != ''){
            if($file_name != ''){
                $upload = upload_file($file_tmp,$file_name,"proj_img/");
                $new_file_name = $upload['data'];
                if($upload['status'] == 'error'){
                        $error_message = '<div class="alert alert-danger" role="alert">
                                            File Type Is Incorrect!!!
                                            </div>';
                }
                    else if($upload['status'] == 'success'){
                        cleanPosts($link);
                        $insert = mysqli_query($con,"INSERT INTO project (img,name, url)VALUES('$new_file_name','$name','$link')"); 
                        if($insert){
                            $select = mysqli_query($con,"SELECT * FROM project");
                            $fetch_img = mysqli_fetch_assoc($select);
                        }
                            else{
                                $error_message = '<div class="alert alert-danger" role="alert">
                                                    Server Problems
                                                </div>';
                            }
                    }  
            }
                else{
                    $error_message = '<div class="alert alert-warning" role="alert">
                                        Select Image!!!
                                    </div>';
                }
        }
            else{
                $error_message = '<div class="alert alert-danger" role="alert">
                                    Fill All Fields
                                </div>';
            }
        
        //var_dump($fetch_img);
}



?>
<div class = "col-lg-10">
    <form action = "" method = "post" enctype = "multipart/form-data" class = "row justify-content-center border-bottom border-danger pt-5 pb-2">
        <div class = "col-lg-2 row">
            <div class = "mb-2  border">
                <img src = ""  class = "w-100 user_avatar_edit fas fa-image">
            </div>
            <div class="mt-2">
                <input type="file"  name = "images" class="form-control w-100" id="profile_image" aria-describedby="inputGroupFileAddon04" aria-label="Upload">
            </div>
        </div> 
        <div class = "col-lg-5">
            <div class="form-group">
                <label for="exampleInputEmail1">Project Name</label>
                <input type="text" name = "proj_name" class="form-control" id="exampleInputEmail1" value = "" aria-describedby="emailHelp" placeholder="Enter Name">
            </div>
            <div class="form-group mt-2">
                <label for="exampleInputPassword1">Project URL</label>
                <input type="text" name = "proj_url" class="form-control" id="exampleInputEmail1" value = "" aria-describedby="emailHelp" placeholder="Enter URL">
            </div>
            <div class="save_avatar_btn_content mt-2">
                <input type = "submit" name = "save" class = "btn btn-success w-100" value = "Save">
            </div>
        </div>
        <div class = "w-75 mt-2">
            <?=$error_message?>
        </div>
    </form>

    <div class = "mt-3 sortable_table col-lg-6">
        <?php
            $select_all = mysqli_query($con,"SELECT * FROM project ORDER BY position");
            while($fetch = mysqli_fetch_assoc($select_all)){?>
            <ul class = " proj_list my-2 d-flex justify-content-between border-bottom border-danger p-2" data-position = "<?= $fetch['position'] ?>" data-index = "<?= $fetch['id'] ?> style = "list-style:none;">
                <li class = "img list-unstyled w-50">
                    <img src = "proj_img/<?= $fetch['img'];?>" class = "w-100">
                </li>
                    <li class = "d-flex mx-3 flex-column">
                        <label class = "fw-bold fs-3">Project Name</label>
                        <span><?= $fetch['name'];?></span>
                    </li>
                    <li class = "d-flex flex-column">
                        <label class = "fw-bold fs-3">Project Link</label>
                        <a href = "<?= $fetch['url'];?>"><?= $fetch['url'];?></a>
                    </li>
                    <div class = "del_prog m-3 d-flex align-items-center">
                        <i class="fa-solid fa-times delete" data-project_id = "<?= $fetch['id']; ?>"></i>
                    </div>
            </ul>
        <?php
            }
        ?>
    </div>


</div>

<?php
    require_once('footer.php');
?>