﻿$('#btn_link').click(function(){
    if($('#bname').val() == ''){
        $('#bname_sp').text('Please write text *');
    }
    else{
        $('#bname_sp').text('');
    }
    if($('#author').val() == ''){
        $('#author_sp').text('Please write text *');
    }
    else{
        $('#author_sp').text('');
    }

    if($('#genre').val() ){
        $('#select_sp').text('');
    }
    else{
        $('#select_sp').text('Please choose one *');
    }
    if($('#language').val() ){
        $('#select_sp_lng').text('');
    }
    else{
        $('#select_sp_lng').text('Please choose one *');
    }
})



/*function f1(){
    var name = document.querySelector('#bname').value;
    var author = document.querySelector('#author').value;
    var genre = document.querySelector('#genre').value; 
    var language = document.querySelector('#language').value; 

    if(name == ''){
        alert('error');
    }

}*/